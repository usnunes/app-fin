<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('records', function (Blueprint $table) {
            $table->increments('id');
            $table->foreignId('category_id'); //usará convenções para determinar o nome da tabela e da coluna que está sendo referenciada
            $table->foreignId('origin_id');
            //$table->foreignId('user_id');
            $table->string('description',200);
            $table->date('release_date')->useCurrent(); //data de lançamento
            $table->date('due_date');                   //data de vencimento            
            $table->date('payment_date');               //data de pagamento
            $table->decimal('amount');                  //valor do lançamento
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('records');
    }
};
